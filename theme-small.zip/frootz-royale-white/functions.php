<?php
/**
 * Frootz Royale White — theme functions
 */

if (!defined('ABSPATH')) { exit; }

add_action('after_setup_theme', function() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);
});

add_action('wp_enqueue_scripts', function() {
    $ver = wp_get_theme()->get('Version');
    wp_enqueue_style('frootz-royale-fonts',
        'https://fonts.googleapis.com/css2?family=Glass+Antiqua&family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,700&family=Inter:wght@300;400;500;600;700&display=swap',
        [], null);
    wp_enqueue_style('frootz-royale-style', get_stylesheet_uri(), [], $ver);
    wp_enqueue_script('frootz-royale-main',
        get_template_directory_uri() . '/assets/js/main.js',
        [], $ver, true);
});

// Keep WP from injecting default emoji scripts (we don't need them, cleaner HTML)
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
